<?php

namespace WP_Smart_Image_Resize\Filters;

abstract class Base_Filter
{
    abstract public function listen();
}
