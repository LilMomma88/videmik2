<?php

namespace WP_Smart_Image_Resize\Events;

abstract class Base_Event
{
    abstract public function listen();
}
